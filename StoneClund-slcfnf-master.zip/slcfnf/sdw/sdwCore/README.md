# slcfnf-core

#### 介绍
盛莲新架构，通用core包
