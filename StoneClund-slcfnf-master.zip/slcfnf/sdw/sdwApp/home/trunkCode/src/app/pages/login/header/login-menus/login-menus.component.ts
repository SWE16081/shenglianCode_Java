import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-login-menus',
  templateUrl: './login-menus.component.html',
  styleUrls: ['./login-menus.component.css']
})
export class LoginMenusComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
