# slcfnf

#### 介绍
盛莲新架构

#### 软件架构
软件架构说明：
1.  cfms-理财核心代码模块
2.  sdwApp-前端代码模块
    2.1. admin-后端管理界面
    2.2. home-pc用户界面
    2.3. mobile-手机用户界面
3.  sdwCore-sdw包管理
    3.1. cfms-core-理财核心代码core包
4.  sdwDb-sdwdb管理模块
5.  sdwPortal-系统范文门户管理模块